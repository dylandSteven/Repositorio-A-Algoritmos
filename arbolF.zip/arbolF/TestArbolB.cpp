#include "ArbolB.hpp"
#include <stdlib.h>
#include <time.h>
#include <iostream>

using namespace std;

void imprimir(int e) {
	cout << " " << e;
}

int main() {
	//srand(time(0));
	
	function<void(int)> proc = [](int a) {		
        cout << a << endl;
    };
	
	function<int(int,int)> comp = [](int a,int b) {		
        if(a < b){
        	return 0; 
		}//>=
		else if (a >= b){
			return 1;
		}
    };
	
	
	ArbolB<int>* arbol = new ArbolB<int>(proc,comp);
	/*
	for (int i = 0; i < 30; ++i) {
		arbol->insertar(rand() % 100);
	}*/
	//***Pruebas***
	//Ingreso manual
	//Caso 1:
	//arbol->insertar(6);
	//arbol->insertar(16);
	//arbol->insertar(26);

	//Caso 2
	arbol->insertar(50);
	arbol->insertar(40);
	arbol->insertar(80);
	arbol->insertar(30);
	arbol->insertar(46);
	arbol->insertar(10);
	arbol->insertar(41);
	arbol->insertar(70);
	arbol->insertar(77);
	arbol->insertar(79);

	
	cout << "LA ALTURA ES:" << endl;
	cout << arbol->altura() << endl;
	
	
//	arbol->porNiv();
	/*
	cout << "EnOrden";
	arbol->enOrden();
	cout << endl;

	cout << "PreOrden";
	//arbol->preOrden();
	cout << endl;


	cout << "Altura: " << arbol->altura() << endl;
	cout << "Cantidad: " << arbol->cantidad() << endl;
	
	*/
	/*
	cout << "PostOrden" << endl;;
	arbol->preOrden();
	cout << endl;
	*/
	cout << "CANT DE" << endl;
	cout << arbol->cantIz() << endl;
	
	cout << "SUMA" << endl;
	cout << arbol->suma() << endl;

	/*
	cout << "ARBOL ESPEJO" << endl;
	
	auto arbol2 = arbol->Espejo();
	cout << "PostOrden" << endl;;
	arbol2->postOrden();
	cout << endl;
	*/
	
	cin.get();

	return 0;
}
