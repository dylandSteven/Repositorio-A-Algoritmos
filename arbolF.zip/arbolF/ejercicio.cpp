#include "ArbolB.hpp"
#include <stdlib.h>
#include <time.h>
#include <iostream>

using namespace std;

class Persona{
	public:
	int dni;
	string apaterno;
	string amaterno;
	string nombre;
	int fnac;
	Persona(){}
	Persona(int d, string ap, string am, string n, int fn): dni(d), apaterno(ap), amaterno(am), nombre(n), fnac(fn){	
	}	
};

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);


	function<void(Persona)> proc = [](Persona a) {		
        cout << a.dni << endl;
    };

	function<int(Persona,Persona)> comp1 = [](Persona a,Persona b) {		
        if(a.dni < b.dni){
        	return 0;
		}
		else{
			return 1;
		}
    };

	function<int(Persona,Persona)> comp2 = [](Persona a, Persona b) {		
        if(a.apaterno < b.apaterno){
        	return 0;
		}
		else{
			return 1;
		}
    };
	
	function<int(Persona,Persona)> comp3 = [](Persona a,Persona b) {		
        if(a.amaterno < b.amaterno){
        	return 0;
		}
		else{
			return 1;
		}
    };
    
	ArbolB<Persona>* arbolDNI = new ArbolB<Persona>(proc,comp1);
	ArbolB<Persona>* arbolAP = new ArbolB<Persona>(proc,comp2);
	ArbolB<Persona>* arbolAM = new ArbolB<Persona>(proc,comp3);
	
	vector<Persona> personas;
	
	personas.push_back(Persona(32,"LOPEZ","MAITE","TITO",1975));
	personas.push_back(Persona(45,"PEREZ","LIRA","JACK",1900));
	personas.push_back(Persona(88,"ROCA","RUIZ","LUIS",2000));
	personas.push_back(Persona(99,"AVILA","YEN","VIVIAN",1999));
	personas.push_back(Persona(23,"BROCA","TORRES","ARMIE",1998));
	personas.push_back(Persona(76,"NUNEZ","WU","JOSUE",1980));
	personas.push_back(Persona(68,"ALVA","ROSAS","ALONSO",1980));
	

	
	for(Persona elem: personas){
		arbolDNI->insertar(elem);
	}
	
	for(Persona elem: personas){
		arbolAP->insertar(elem);
	}
	
	for(Persona elem: personas){
		arbolAM->insertar(elem);
	}
	
	arbolAP->porNiv();
	return 0;
}

