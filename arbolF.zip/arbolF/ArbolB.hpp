#ifndef __ARBOLB_HPP__
#define __ARBOLB_HPP__
#include <functional>
#include <iostream>
#include <queue>
template <class T>
class Nodo {
public:
	T elemento;
	Nodo* izq;
	Nodo* der;
};

template <class T>
class ArbolB {
	Nodo<T>* raiz;
	
    std::function<void(T)> procesar;
	std::function<int(T,T)> comp;
private:
	
	
	void setP(std::function<void(T)> c){
		procesar = c;
	}
	
	void _preOrdenE(Nodo<T>* nodo, std::function<void(T)> p) {
		if (nodo == nullptr) return;
		p(nodo->elemento);
		_preOrdenE(nodo->izq,p);
		_preOrdenE(nodo->der,p);
	}


	
	ArbolB* espejo(){
		
		std::function<int(T,T)> cmp = [&](int a,int b) {		 	
        	if(a < b){
        		return 1; // manda a la derecha
			}
			else if(a >= b){
				return 0; // manda a la izquierda
			}
   		};
   		
		/* 
		original
		function<int(int,int)> comp = [](int a,int b) {		
	        if(a < b){
	        	return 0; 
			}//>=
			else{
				return 1;
			}
    	};
		*/	
		ArbolB<T>* arbol = new ArbolB<T>(procesar,cmp);
		
		std::function<void(T)> proc = [&](T a) {		
       		arbol->insertar(a);
   		};
   		
   		_preOrdenE(raiz,proc);
   		return arbol;	
	}
	
	

	
	int cont(Nodo<T>* nodo) {
		if (nodo == nullptr) return 0;
		int t = 1;
		t +=  cont(nodo->izq) + cont(nodo->der);
		return t;
	}
	
	
	
	int sumar(Nodo<T>* nodo) {
		if (nodo == nullptr) return 0;
		int t = nodo->elemento;
		t +=  sumar(nodo->izq) + sumar(nodo->der);
		return t;
	}
	
	
	
	// si es 0 manda a la izquierda // si es 1 manda a la derecha
	// 1 // 0
	
	bool _insertar(Nodo<T>*& nodo, T e) {
		if (nodo == nullptr) {
			nodo = new Nodo<T>();
			nodo->elemento = e;
			return true;
		}
		else if (comp(e,nodo->elemento) == 0) { // e < nodo->elemento
 			return _insertar(nodo->izq, e);
		}
		else if (comp(e,nodo->elemento) == 1) { // e >= nodo->elemento
			return _insertar(nodo->der, e);
		}
	}
	
	
	
	void _enOrden(Nodo<T>* nodo) {
		if (nodo == nullptr) return;
		_enOrden(nodo->izq);
		procesar(nodo->elemento);
		_enOrden(nodo->der);
	}

	void _preOrden(Nodo<T>* nodo) {
		if (nodo == nullptr) return;
		procesar(nodo->elemento);
		_preOrden(nodo->izq);
		_preOrden(nodo->der);
	}

	void _postOrden(Nodo<T>* nodo) {
		if (nodo == nullptr) return;
		_postOrden(nodo->izq);
		_postOrden(nodo->der);
		procesar(nodo->elemento);
	}
	
	
	
	bool _vacio() {
		return raiz == nullptr;
	}
	
	int _cantidad(Nodo<T>* nodo) {
		//La cantidad de nodos del �rbol es:
		//	0 si es vac�o
		//	1 + la cantidad de nodos por la izquierda + la cantidad de nodos por la derecha

		if (nodo==nullptr)
			return 0;
		else
		{
			int ci, cd;
			ci = _cantidad(nodo->izq);
			cd = _cantidad(nodo->der);
			return 1 + ci + cd;
		}
	}
	
	int _altura(Nodo<T>* nodo) {
		//La altura del �rbol es:
		//	0 si es vac�o
		//	la mayor de las alturas por la izquierda y por la derecha, las cu�les son 0 si son vac�as � 1 + la altura por la izq(o der) en caso contrario

		if (nodo==nullptr)
			return -1;
		else
		{
			int ai, ad;
			ai = 1 + _altura(nodo->izq);
			ad = 1 + _altura(nodo->der);
			return ai > ad ? ai : ad;			
		}
	}
	
	// permite mostrar por nivel en O(n^2)
	void mostrarNivel(Nodo<T>* nodo) 
	{ 
	    int h = _altura(nodo); 
	    int i; 
	    
	    for (i = 0; i <= h; i++) {
	       	std::cout << "EL NIVEL ACTUAL ES: " << i << std::endl;
			ubicarNodoNivel(nodo, i); 
		}
	}


	void ubicarNodoNivel(Nodo<T>* nodo, int level) 
	{ 
	    if (nodo == NULL) 
	        return; 
	    if (level == 0) 
	        procesar(nodo->elemento);
	    else if (level > 0) 
	    { 
	        ubicarNodoNivel(nodo->izq, level-1); 
	        ubicarNodoNivel(nodo->der, level-1); 
	    } 
	}
	
	//permite mostrar por nivel en O(n)
	void mostrarNivel2(Nodo<T> *nodo)
	{
	    if (nodo == nullptr)  return;	 
	    std::queue<Nodo<T>*> q;	 
	    q.push(nodo);
	    while (q.empty() == false)
	    {
	        Nodo<T> *act = q.front();
	        std::cout << act->elemento << " ";
	        q.pop();
	 
	        if (act->izq != nullptr)
	            q.push(act->izq);
	 
	        if (act->der != nullptr)
	            q.push(act->der);
	    }
	}
	
public:
	ArbolB(std::function<void(T)> c , std::function<int(T,T)> com) : procesar(c), comp(com){
		raiz = nullptr;
	}
	
	ArbolB* Espejo(){
		return espejo();
	}
	
	bool insertar(T e) {
		return _insertar(raiz, e);
	}
	void enOrden() {
		_enOrden(raiz);
	}
	void preOrden() {
		_preOrden(raiz);
	}
	void postOrden() {
		_postOrden(raiz);
	}
	int cantidad() {
		return _cantidad(raiz);
	}
	int altura() {
		return _altura(raiz);
	}
	int cantIz(){
		return cont(raiz->izq);
	}
	
	int cantDe(){
		return cont(raiz->der);
	}
	
	int suma(){
		return sumar(raiz);
	}
	
	void porNiv(){
		mostrarNivel2(raiz);
	}
};

#endif
